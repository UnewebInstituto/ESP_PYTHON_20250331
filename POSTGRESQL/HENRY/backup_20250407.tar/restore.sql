--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE bd_ig_henry;
--
-- Name: bd_ig_henry; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE bd_ig_henry WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Spanish_Venezuela.1252';


ALTER DATABASE bd_ig_henry OWNER TO postgres;

\connect bd_ig_henry

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: contactos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contactos (
    nombre character varying(80),
    apellido character varying(80),
    fechanac date,
    telefono character varying(20),
    correo character varying(60),
    cedula character varying(15)
);


ALTER TABLE public.contactos OWNER TO postgres;

--
-- Name: TABLE contactos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.contactos IS 'Ejemplo de tabla secuencial';


--
-- Name: contactos1; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contactos1 (
    nombre character varying(80),
    apellido character varying(80),
    fechanac date,
    telefono character varying(20),
    correo character varying(60),
    cedula character varying(15)
);


ALTER TABLE public.contactos1 OWNER TO postgres;

--
-- Name: TABLE contactos1; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.contactos1 IS 'Tabla con índice único';


--
-- Name: contactos2; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contactos2 (
    nombre character varying(80),
    apellido character varying(80),
    fechanac date,
    telefono character varying(20),
    correo character varying(60),
    cedula character varying(15)
);


ALTER TABLE public.contactos2 OWNER TO postgres;

--
-- Name: contactos3; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contactos3 (
    id integer NOT NULL,
    nombre character varying(80),
    apellido character varying(80),
    fechanac date,
    telefono character varying(20),
    correo character varying(60) NOT NULL,
    cedula character varying(15) NOT NULL
);


ALTER TABLE public.contactos3 OWNER TO postgres;

--
-- Name: TABLE contactos3; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.contactos3 IS 'Ejemplo de tabla que contendrá clave primaria para un campo serial, identficado con el nombre id';


--
-- Name: contactos3_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contactos3_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.contactos3_id_seq OWNER TO postgres;

--
-- Name: contactos3_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contactos3_id_seq OWNED BY public.contactos3.id;


--
-- Name: contactos4; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contactos4 (
    id bigint NOT NULL,
    nombre character varying(80),
    apellido character varying(80),
    fechanac date,
    telefono character varying(20),
    correo character varying(60),
    cedula character varying(15)
);


ALTER TABLE public.contactos4 OWNER TO postgres;

--
-- Name: contactos4_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contactos4_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.contactos4_id_seq OWNER TO postgres;

--
-- Name: contactos4_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contactos4_id_seq OWNED BY public.contactos4.id;


--
-- Name: productos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.productos (
    id integer NOT NULL,
    proveedor_id integer,
    nombre character varying(30),
    precio numeric(13,2),
    existencia integer
);


ALTER TABLE public.productos OWNER TO postgres;

--
-- Name: productos1; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.productos1 (
    id integer NOT NULL,
    proveedor_id integer,
    nombre character varying(30),
    precio numeric(13,2),
    existencia integer
);


ALTER TABLE public.productos1 OWNER TO postgres;

--
-- Name: productos1_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.productos1_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.productos1_id_seq OWNER TO postgres;

--
-- Name: productos1_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.productos1_id_seq OWNED BY public.productos1.id;


--
-- Name: productos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.productos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.productos_id_seq OWNER TO postgres;

--
-- Name: productos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.productos_id_seq OWNED BY public.productos.id;


--
-- Name: proveedores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.proveedores (
    id integer NOT NULL,
    nombre character varying(30),
    direccion text,
    telefono character varying(20),
    correo character varying(60)
);


ALTER TABLE public.proveedores OWNER TO postgres;

--
-- Name: proveedores1; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.proveedores1 (
    id integer NOT NULL,
    nombre character varying(30),
    direccion text,
    telefono character varying(20),
    correo character varying(60)
);


ALTER TABLE public.proveedores1 OWNER TO postgres;

--
-- Name: proveedores1_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.proveedores1_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.proveedores1_id_seq OWNER TO postgres;

--
-- Name: proveedores1_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.proveedores1_id_seq OWNED BY public.proveedores1.id;


--
-- Name: proveedores_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.proveedores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.proveedores_id_seq OWNER TO postgres;

--
-- Name: proveedores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.proveedores_id_seq OWNED BY public.proveedores.id;


--
-- Name: vista_prov_prod; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vista_prov_prod AS
 SELECT a.nombre AS proveedor,
    a.telefono,
    a.correo,
    b.nombre AS producto,
    b.precio,
    b.existencia
   FROM public.proveedores a,
    public.productos b
  WHERE (b.proveedor_id = a.id);


ALTER VIEW public.vista_prov_prod OWNER TO postgres;

--
-- Name: contactos3 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contactos3 ALTER COLUMN id SET DEFAULT nextval('public.contactos3_id_seq'::regclass);


--
-- Name: contactos4 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contactos4 ALTER COLUMN id SET DEFAULT nextval('public.contactos4_id_seq'::regclass);


--
-- Name: productos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.productos ALTER COLUMN id SET DEFAULT nextval('public.productos_id_seq'::regclass);


--
-- Name: productos1 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.productos1 ALTER COLUMN id SET DEFAULT nextval('public.productos1_id_seq'::regclass);


--
-- Name: proveedores id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proveedores ALTER COLUMN id SET DEFAULT nextval('public.proveedores_id_seq'::regclass);


--
-- Name: proveedores1 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proveedores1 ALTER COLUMN id SET DEFAULT nextval('public.proveedores1_id_seq'::regclass);


--
-- Data for Name: contactos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contactos (nombre, apellido, fechanac, telefono, correo, cedula) FROM stdin;
\.
COPY public.contactos (nombre, apellido, fechanac, telefono, correo, cedula) FROM '$$PATH$$/4851.dat';

--
-- Data for Name: contactos1; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contactos1 (nombre, apellido, fechanac, telefono, correo, cedula) FROM stdin;
\.
COPY public.contactos1 (nombre, apellido, fechanac, telefono, correo, cedula) FROM '$$PATH$$/4852.dat';

--
-- Data for Name: contactos2; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contactos2 (nombre, apellido, fechanac, telefono, correo, cedula) FROM stdin;
\.
COPY public.contactos2 (nombre, apellido, fechanac, telefono, correo, cedula) FROM '$$PATH$$/4853.dat';

--
-- Data for Name: contactos3; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contactos3 (id, nombre, apellido, fechanac, telefono, correo, cedula) FROM stdin;
\.
COPY public.contactos3 (id, nombre, apellido, fechanac, telefono, correo, cedula) FROM '$$PATH$$/4855.dat';

--
-- Data for Name: contactos4; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contactos4 (id, nombre, apellido, fechanac, telefono, correo, cedula) FROM stdin;
\.
COPY public.contactos4 (id, nombre, apellido, fechanac, telefono, correo, cedula) FROM '$$PATH$$/4857.dat';

--
-- Data for Name: productos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.productos (id, proveedor_id, nombre, precio, existencia) FROM stdin;
\.
COPY public.productos (id, proveedor_id, nombre, precio, existencia) FROM '$$PATH$$/4861.dat';

--
-- Data for Name: productos1; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.productos1 (id, proveedor_id, nombre, precio, existencia) FROM stdin;
\.
COPY public.productos1 (id, proveedor_id, nombre, precio, existencia) FROM '$$PATH$$/4865.dat';

--
-- Data for Name: proveedores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.proveedores (id, nombre, direccion, telefono, correo) FROM stdin;
\.
COPY public.proveedores (id, nombre, direccion, telefono, correo) FROM '$$PATH$$/4859.dat';

--
-- Data for Name: proveedores1; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.proveedores1 (id, nombre, direccion, telefono, correo) FROM stdin;
\.
COPY public.proveedores1 (id, nombre, direccion, telefono, correo) FROM '$$PATH$$/4863.dat';

--
-- Name: contactos3_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contactos3_id_seq', 4, true);


--
-- Name: contactos4_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contactos4_id_seq', 3, true);


--
-- Name: productos1_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.productos1_id_seq', 16, true);


--
-- Name: productos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.productos_id_seq', 16, true);


--
-- Name: proveedores1_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.proveedores1_id_seq', 4, true);


--
-- Name: proveedores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.proveedores_id_seq', 4, true);


--
-- Name: contactos3 contactos3_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contactos3
    ADD CONSTRAINT contactos3_pkey PRIMARY KEY (id, cedula, correo);


--
-- Name: contactos4 contactos4_cedula_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contactos4
    ADD CONSTRAINT contactos4_cedula_key UNIQUE (cedula);


--
-- Name: contactos4 contactos4_correo_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contactos4
    ADD CONSTRAINT contactos4_correo_key UNIQUE (correo);


--
-- Name: contactos4 contactos4_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contactos4
    ADD CONSTRAINT contactos4_pkey PRIMARY KEY (id);


--
-- Name: productos1 productos1_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.productos1
    ADD CONSTRAINT productos1_pkey PRIMARY KEY (id);


--
-- Name: productos productos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_pkey PRIMARY KEY (id);


--
-- Name: proveedores1 proveedores1_correo_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proveedores1
    ADD CONSTRAINT proveedores1_correo_key UNIQUE (correo);


--
-- Name: proveedores1 proveedores1_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proveedores1
    ADD CONSTRAINT proveedores1_pkey PRIMARY KEY (id);


--
-- Name: proveedores proveedores_correo_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proveedores
    ADD CONSTRAINT proveedores_correo_key UNIQUE (correo);


--
-- Name: proveedores proveedores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proveedores
    ADD CONSTRAINT proveedores_pkey PRIMARY KEY (id);


--
-- Name: contactos2 uniq_ced_cor; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contactos2
    ADD CONSTRAINT uniq_ced_cor UNIQUE (cedula, correo);


--
-- Name: contactos1 uniq_cedula; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contactos1
    ADD CONSTRAINT uniq_cedula UNIQUE (cedula);


--
-- Name: productos fk_proveedor_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT fk_proveedor_id FOREIGN KEY (proveedor_id) REFERENCES public.proveedores(id);


--
-- Name: CONSTRAINT fk_proveedor_id ON productos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT fk_proveedor_id ON public.productos IS 'Este es un ejemplo de asociación entre tablas';


--
-- Name: productos1 productos1_proveedor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.productos1
    ADD CONSTRAINT productos1_proveedor_id_fkey FOREIGN KEY (proveedor_id) REFERENCES public.proveedores1(id) NOT VALID;


--
-- PostgreSQL database dump complete
--

